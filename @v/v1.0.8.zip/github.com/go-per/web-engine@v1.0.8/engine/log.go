package engine

import "fmt"

// ILogger interface
type ILogger interface {
	Printf(format string, args ...interface{})
	Debug(i ...interface{})
	Info(i ...interface{})
	Warn(i ...interface{})
	Error(i ...interface{})
	Panic(i ...interface{})
}

// DefaultLogger struct
type DefaultLogger struct{}

// Printf function
func (logger DefaultLogger) Printf(format string, args ...interface{}) {
	fmt.Printf(format, args...)
}

// Debug func
func (logger DefaultLogger) Debug(i ...interface{}) {
	logger.Printf("[DEBUG] %v", i...)
}

// Info func
func (logger DefaultLogger) Info(i ...interface{}) {
	logger.Printf("[INFO] %v", i...)
}

// Warn func
func (logger DefaultLogger) Warn(i ...interface{}) {
	logger.Printf("[WARN] %v", i...)
}

// Error func
func (logger DefaultLogger) Error(i ...interface{}) {
	logger.Printf("[ERROR] %v", i...)
}

// Panic func
func (logger DefaultLogger) Panic(i ...interface{}) {
	panic(fmt.Sprintf("[PANIC] %v", i...))
}
